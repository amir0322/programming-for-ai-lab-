import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')

my_text = "I am currently studying Data Science in my fourth semester"

words = word_tokenize(my_text)

stop_words = set(stopwords.words('english'))

result = []
for w in words:
    if w.lower() not in stop_words:
        result.append(w)

print("Original Words:", words)
print("After Removing Stopwords:", result)
