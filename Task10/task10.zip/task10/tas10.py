from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# All responses are stored in this dictionary
answers = {
    "admission": "Admissions open for Fall 2026. Go to website and apply.",
    "deadline": "Last date to apply is 15 August.",
    "program": "We have BS Data Science, AI, CS and Software Engineering.",
    "fee": "Fee depends on program but for Data Science its around 120,000 per semester.",
    "location": "Main campus is in Lahore.",
    "hi": "Hello! Ask me about admissions!",
    "hello": "Hi there! What do you want to know?",
    "bye": "Bye! Good luck!"
}

def get_response(input_text):
    # Convert to lowercase for matching
    input_text = input_text.lower()
    
    # Check if any keyword matches
    for k in answers:
        if k in input_text:
            return answers[k]
    
    # Default message if nothing matches
    return "I didn't understand. Ask about admission, program, fee, or deadline."

# Main page
@app.route("/")
def home():
    return render_template("index.html")

# API endpoint for chat responses
@app.route("/get")
def bot_reply():
    msg = request.args.get('msg')
    ans = get_response(msg)
    return jsonify({"response": ans})

if __name__ == "__main__":
    app.run(debug=True)